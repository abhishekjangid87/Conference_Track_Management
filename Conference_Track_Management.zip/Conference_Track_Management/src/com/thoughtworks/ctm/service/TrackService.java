package com.thoughtworks.ctm.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.thoughtworks.ctm.entity.Talk;
import com.thoughtworks.ctm.entity.Track;

public class TrackService {

	TalkService talkService = new TalkService();
	int morningSessionTime = 180; // in mins
	int afternoonSessionInTime = 240; // in mins
	Track[] tracks = null;
	List<Track> trackList = new ArrayList();
	
	public List<Track> getTotalNumberOfTrackes(HashMap<Talk, Integer> talks) {
		

		int totalTime = 0;
		for (Map.Entry<Talk, Integer> m : talks.entrySet()) {
			totalTime = totalTime + m.getValue();
		}
		int totalTrackes = totalTime / (morningSessionTime + afternoonSessionInTime) + 1;
		tracks = new Track[totalTrackes];
		for (int i = 0; i < totalTrackes; i++) {
			tracks[i] = new Track(new HashMap<Talk, Integer>(), new HashMap<Talk, Integer>());
		}

		trackList = Arrays.asList(tracks);
		return trackList;
	}
	
	/**
	 * @param talks
	 * @return
	 * @throws IOException 
	 */
	public List<Track> createTracks(BufferedReader br) throws IOException {
		HashMap<Talk, Integer> talks = null;
		talks = talkService.getAllTalksWithDuration(br);
		List<Track> trackList = getTotalNumberOfTrackes(talks);
		int i = 0;
		int mSessionTime = 0;
		int aSessionTime = 0;
		List<Map.Entry<Talk, Integer>> listForValueSum = new ArrayList<Map.Entry<Talk, Integer>>(talks.entrySet());
		int sumOfValues = 0;
		for (Map.Entry<Talk, Integer> m : listForValueSum) {
			sumOfValues = sumOfValues + m.getValue();
		}
		// sort the Map in ascending order based on value
		List<Map.Entry<Talk, Integer>> talkList = new LinkedList<Map.Entry<Talk, Integer>>(talks.entrySet());
		Collections.sort(talkList, new Comparator<Map.Entry<Talk, Integer>>() {
			public int compare(Map.Entry<Talk, Integer> o1, Map.Entry<Talk, Integer> o2) {
				return (o1.getValue().compareTo(o2.getValue()));
			}
		});
		HashMap<Talk, Integer> sortedTalks = new LinkedHashMap<Talk, Integer>();
		for (Map.Entry<Talk, Integer> m : talkList) {
			sortedTalks.put(m.getKey(), m.getValue());
		}

		for (Map.Entry<Talk, Integer> m : sortedTalks.entrySet()) {
			//System.out.println(m);

			mSessionTime = mSessionTime + m.getValue();
			if (mSessionTime <= 180) {
				trackList.get(i).getMorningSession().put(m.getKey(), m.getValue());

			} else if (mSessionTime > 180) {
				aSessionTime = aSessionTime + m.getValue();
				if (aSessionTime <= 240) {
					trackList.get(i).getAfternoonSession().put(m.getKey(), m.getValue());
				}
			}
			if (mSessionTime >= 180 && aSessionTime > 240) {
				i++;
				aSessionTime = 0;
				mSessionTime = m.getValue();
				trackList.get(i).getMorningSession().put(m.getKey(), m.getValue());
			}
		}

		return trackList;
	}
	
	public List<Track> getAllTracksWithRespectiveTalks(BufferedReader br) throws IOException{
		
		return createTracks(br);
		
	}
}
