package com.thoughtworks.ctm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.thoughtworks.ctm.entity.Talk;
import com.thoughtworks.ctm.entity.Track;

public class ConferenceService {

	

	public void showConferenceTracks(List<Track> tracks) throws ParseException {
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
		Calendar calendar = Calendar.getInstance();
		try {
			for (int i = 0; i < tracks.size(); i++) {
				int m = 0, n = 0, mmins = 0, amins = 0;
				System.out.println("\n");
				System.out.println("Track: " + (i + 1));

				for (Map.Entry<Talk, Integer> ms : tracks.get(i).getMorningSession().entrySet()) {
					if (m == 0) {
						date = sdf.parse("09:00 AM");
						System.out.println(sdf.format(date) + " " + ms.getKey());
					} else {
						System.out.println(sdf.format(calendar.getTime()) + " " + ms.getKey());
					}
					mmins = mmins + Integer.parseInt(ms.getValue().toString());
					calendar.setTime(date);
					calendar.add(Calendar.MINUTE, mmins);
					m = m + 1;

				}
				System.out.println("12:00 PM Lunch");
				for (Map.Entry<Talk, Integer> as : tracks.get(i).getAfternoonSession().entrySet()) {
					if (n == 0) {
						date = sdf.parse("01:00 PM");
						System.out.println(sdf.format(date) + " " + as.getKey());
					} else {
						System.out.println(sdf.format(calendar.getTime()) + " " + as.getKey());
					}
					amins = amins + Integer.parseInt(as.getValue().toString());
					calendar.setTime(date);
					calendar.add(Calendar.MINUTE, amins);
					n = n + 1;
				}
				if (((sdf.format(calendar.getTime()).compareTo("04:00 PM")) >= 0)
						&& ((sdf.format(calendar.getTime()).compareTo("05:00 PM")) <= 0))
					System.out.println(sdf.format(calendar.getTime()) + " " + "Networking Event");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		File file = null;
		BufferedReader br = null;
		List<Track> tracks = null;
		ConferenceService conference = new ConferenceService();
		TrackService trackService = new TrackService();
		Scanner sc = new Scanner(System.in);

		try {		
			 System.out.println("Provide full file path");
			 
			 String filePath = sc.nextLine();
			//String filePath = "E://Work Practise/Projects/Conference_Track_Management/src/resources/Sample Input.txt";
			file = new File(filePath);
			
			br = new BufferedReader(new FileReader(file));
			
			
			tracks = trackService.getAllTracksWithRespectiveTalks(br);
			
			conference.showConferenceTracks(tracks);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			sc.close();
		} 
		  catch (IOException e) {
			e.printStackTrace();
			sc.close();
		}
		  catch (ParseException e) {
			e.printStackTrace();
			sc.close();
		} 
		  finally {
			sc.close();
		}

	}

}
