package com.thoughtworks.ctm.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

import com.thoughtworks.ctm.entity.Talk;

public class TalkService {
	
	HashMap<Talk, Integer> talks = new HashMap();

	public HashMap<Talk, Integer> getAllTalksWithDuration(BufferedReader br) throws IOException {
		
		String st = null;
		String[] arr = null;
		try {
			while ((st = br.readLine()) != null) {
				arr = st.split(" ");
				String key = st;
				int value = 0;

				for (String a : arr) {
					if (a.length() >= 3 && a.substring(a.length() - 3, a.length()).equals("min")) {
						value = Integer.parseInt(a.substring(0, a.length() - 3));
					} else if (a.equals("lightning")) {
						value = Integer.parseInt("5");
					}
				}
				if (st.contains("min") || st.contains("lightning")) {
					if (st.contains("min"))
						talks.put(new Talk(key.substring(0, st.lastIndexOf("min") - 3)), value);
					else if (st.contains("lightning"))
						talks.put(new Talk(key.substring(0, st.lastIndexOf("lightning"))), value);
				}
			}

			return talks;
		} catch (Exception e) {
			System.out.println("Remove blank space from time value and min from: " + st);
			e.printStackTrace();
			return null;
		}

	}
}
