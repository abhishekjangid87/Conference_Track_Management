package com.thoughtworks.ctm.entity;

public class Talk {
	
	private String talk = null;
	
	public Talk(String talk) {
		this.talk = talk;
	}
	public String getTalk() {
		return talk;
	}
	public void setTalk(String talk) {
		this.talk = talk;
	}
	@Override
	public String toString() {
		return talk;
	}

}
