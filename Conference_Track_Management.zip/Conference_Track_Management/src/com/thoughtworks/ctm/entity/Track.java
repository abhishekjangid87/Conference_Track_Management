package com.thoughtworks.ctm.entity;

import java.util.HashMap;

public class Track {
	
	HashMap<Talk, Integer> morningSession = null;
	HashMap<Talk, Integer> afternoonSession = null;
	public Track(HashMap<Talk, Integer> morningSession, HashMap<Talk, Integer> afternoonSession) {
		this.morningSession = morningSession;
		this.afternoonSession = afternoonSession;
	}
	public HashMap<Talk, Integer> getMorningSession() {
		return morningSession;
	}
	public void setMorningSession(HashMap<Talk, Integer> morningSession) {
		this.morningSession = morningSession;
	}
	public HashMap<Talk, Integer> getAfternoonSession() {
		return afternoonSession;
	}
	public void setAfternoonSession(HashMap<Talk, Integer> afternoonSession) {
		this.afternoonSession = afternoonSession;
	}

	
}
